package bruni.springthymeleafcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringThymeleafCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringThymeleafCrudApplication.class, args);
    }

}
