package bruni.springthymeleafcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringThymeleafCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
